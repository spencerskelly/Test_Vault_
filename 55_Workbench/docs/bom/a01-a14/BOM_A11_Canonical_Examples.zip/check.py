from pathlib import Path
import re
p=Path(__file__).parent
notes={f.stem:f.read_text() for f in p.glob('Fixture*.md')}
assert len(notes)==5
ids=[];uids=[];blocks=[]
for name,txt in notes.items():
 assert txt.startswith('---\ntype: Object\n')
 ids += re.findall(r'^id: (OBJ-\d{5})$',txt,re.M)
 uids += re.findall(r'^uid: (\d{17}[a-z-]{13})$',txt,re.M)
 blocks += re.findall(r'^\^(part-\d{17}[a-z-]{13})$',txt,re.M)
 assert '# '+name in txt
assert len(ids)==len(set(ids))==5
assert len(uids)==len(set(uids))==5
assert len(blocks)==len(set(blocks))==4
assert not set(x.replace('part-','') for x in blocks)&set(uids)
assert 'subtype:' not in notes['Fixture Charger Family']
for k in ['Fixture Charger Assembly A','Fixture Charger Assembly B']:
 t=notes[k]
 assert t.count('variantOf:')==1 and t.count('[[Fixture Charger Family]]')==1
 assert t.count('definition: [[Fixture Wire]]')==1
 assert t.count('definition: [[Fixture Fastener]]')==1
 assert t.count('<!-- MDSE:LOCAL-MODEL START schema=0.6 -->')==1
 assert t.count('<!-- MDSE:LOCAL-MODEL END -->')==1
 assert t.count('unitOfMeasure: m')==1
 assert t.count('^part-')==2
for k in ['Fixture Wire','Fixture Fastener']:
 assert 'partOf:' not in notes[k] and 'usedBy:' not in notes[k]
assert all('subtypeOf:' not in t for t in notes.values())
print('PASS: 5 notes; 5 unique IDs and UIDs; 4 unique Part block IDs; parent ownership, forward variants, links, units, no inferred inheritance')
print('LIMITATION: proposed 0.6 only; not validated by MDSE Workbench')
