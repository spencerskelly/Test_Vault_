---
type: Object
subtype: part
id: OBJ-90002
uid: 20261008095000002skellyspencer
status: Draft
tags: []
---

# Fixture Wire

## Definition

Non-production fixture definition.

## Notes

## Aliases

## Former ids
