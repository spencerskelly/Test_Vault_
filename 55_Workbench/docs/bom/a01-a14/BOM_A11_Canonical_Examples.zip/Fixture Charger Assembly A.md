---
type: Object
subtype: electrical
id: OBJ-90004
uid: 20261008095000004skellyspencer
status: Draft
tags: []
variantOf: "[[Fixture Charger Family]]"
---

# Fixture Charger Assembly A

## Definition

Non-production fixture definition.

## Notes

<!-- MDSE:LOCAL-MODEL START schema=0.6 -->
## Local Model

### Parts

#### W1 — Wire
- definition: [[Fixture Wire]]
- multiplicity: 2
- quantity: 0.35
- unitOfMeasure: m
^part-20261008095100011skellyspencer

#### F1 — Fastener
- definition: [[Fixture Fastener]]
- multiplicity: 4
^part-20261008095100012skellyspencer

<!-- MDSE:LOCAL-MODEL END -->


## Aliases

## Former ids
