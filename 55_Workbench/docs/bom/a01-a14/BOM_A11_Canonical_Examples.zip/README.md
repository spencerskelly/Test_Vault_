# A-11 canonical modeling examples (proposal fixtures only)

These are **NOT current-schema-valid production notes**. They deliberately exercise proposed A-05/A-07/A-09 changes. Do not import these into an existing vault: OBJ-90001..90005 and the example UID values are arbitrary fixture identities, not allocator-reserved IDs. All examples are fictitious.

- `Fixture Charger Family`: subtype omitted (proposed A-09 policy); not `abstract: true`, because variantOf is *not* inheritance.
- Assembly A/B: `variantOf` forward-only to family (proposed A-07/A-08). No `subtypeOf` generated.
- Local Model schema marker `0.6` and part `quantity`, `unitOfMeasure` are proposed (A-05), **not** supported by current governing Local Model 0.5.
- A uses 2 wire occurrences × 0.35 m = 0.70 m, 4 fasteners; B uses 3 × 0.35 m = 1.05 m, 6 fasteners.
- Components have no written `usedBy`, `partOf`, or reverse usage list; a Where Used index scans parent-owned Local Models.

Template source: `Test_Vault_` working branch `importer/baseline-contract-2026-10-05`, `99_System/05_Templates/Object.md`; schema blobs: element-types `3f694feadb2eafd41498aff5ebc24946b9715f6d`, local-model `361dee8269f9fbdfd16bcee33a1b808015f7ba5a`, relationships `413fd5d32d12331413fda30653c7a3a38ac2d2ab`.

## Validation
Run `python3 check.py` in this folder. Fixture validation is structural only and explicitly does not claim that governing MDSE 0.5 tooling can parse/write schema 0.6.
