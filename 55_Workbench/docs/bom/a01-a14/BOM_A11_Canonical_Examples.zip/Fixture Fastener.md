---
type: Object
subtype: part
id: OBJ-90003
uid: 20261008095000003skellyspencer
status: Draft
tags: []
---

# Fixture Fastener

## Definition

Non-production fixture definition.

## Notes

## Aliases

## Former ids
