---
type: Object
id: OBJ-90001
uid: 20261008095000001skellyspencer
status: Draft
tags: []
---

# Fixture Charger Family

## Definition

Non-production fixture definition.

## Notes

## Aliases

## Former ids
