---
type: Object
subtype: electrical
id: OBJ-90005
uid: 20261008095000005skellyspencer
status: Draft
tags: []
variantOf: "[[Fixture Charger Family]]"
---

# Fixture Charger Assembly B

## Definition

Non-production fixture definition.

## Notes

<!-- MDSE:LOCAL-MODEL START schema=0.6 -->
## Local Model

### Parts

#### W1 — Wire
- definition: [[Fixture Wire]]
- multiplicity: 3
- quantity: 0.35
- unitOfMeasure: m
^part-20261008095100021skellyspencer

#### F1 — Fastener
- definition: [[Fixture Fastener]]
- multiplicity: 6
^part-20261008095100022skellyspencer

<!-- MDSE:LOCAL-MODEL END -->


## Aliases

## Former ids
