#!/usr/bin/env python3
"""A-06 isolated, proposed Local Model part-record contract test; NOT MDSE/Workbench validation."""
import json, re
from decimal import Decimal
from pathlib import Path

CASES = json.loads((Path(__file__).parent / 'cases.json').read_text())
PLAIN_DECIMAL = re.compile(r'^[0-9]+(?:\.[0-9]+)?$')
POS_INT = re.compile(r'^[1-9][0-9]*$')


def validate(case):
    p, version = case['part'], case['version']
    if not p.get('definition'):
        return False, 'MISSING_DEFINITION', None
    if version != '0.6' and ('quantity' in p or 'unitOfMeasure' in p):
        return False, 'OLD_VERSION_FIELD', None
    # New canonical writer rules. Historic source-shaped multiplicity is not normalized here.
    if 'multiplicity' in p and version == '0.6' and not POS_INT.fullmatch(str(p['multiplicity'])):
        return False, 'MULT_INVALID', None
    has_q, has_u = 'quantity' in p, 'unitOfMeasure' in p
    if has_q != has_u:
        return False, 'Q_PAIR', None
    if not has_q:
        return True, None, None
    raw = str(p['quantity'])
    if not PLAIN_DECIMAL.fullmatch(raw):
        return False, 'Q_LEXEME', None
    q = Decimal(raw)
    if q <= 0:
        return False, 'Q_NONPOSITIVE', None
    if p['unitOfMeasure'] not in CASES['seed_uom_provisional']:
        return False, 'UOM_UNAPPROVED', None
    if (p['unitOfMeasure'] == 'ea' and 'multiplicity' in p and
            case.get('source', {}).get('single_count') is not None and
            not case['source'].get('independent_dual_evidence', False)):
        return False, 'EA_DOUBLE_COUNT', None
    total = q * Decimal(str(p.get('multiplicity', '1')))
    return True, None, str(total)


def main():
    failures = []
    for case in CASES['cases']:
        actual, code, total = validate(case)
        passed = actual == case['valid'] and (actual or code == case['code']) and ('total' not in case or Decimal(total) == Decimal(case['total']))
        print(('PASS' if passed else 'FAIL'), case['id'], f'valid={actual} code={code or "-"}', f'total={total or "-"}')
        if not passed:
            failures.append(case['id'])
    print(f"SUMMARY {len(CASES['cases'])-len(failures)}/{len(CASES['cases'])} passed")
    return 1 if failures else 0

if __name__ == '__main__':
    raise SystemExit(main())
