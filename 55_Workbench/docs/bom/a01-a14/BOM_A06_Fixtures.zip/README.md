# A-06 — Proposed Local Model quantity/UOM test fixtures

Scope: isolated semantic tests for the proposed 0.6 part-record additions from A-05, **not** the authoritative MDSE validator.

Run: `python3 check.py`.

`cases.json` defines 24 validity and decimal-consumption cases. `ea`, `in`, `m`, and `kg` are provisional units, not an approved complete registry. The checker covers count-only, material-only, dual, fractional, precision, zero/negative, missing unit, unknown unit, case-sensitive alias, scientific notation, NaN, range, multiplicity invalid values, old-version rejection of new fields, and the `ea` double-count trap.

Boundaries: no full Markdown/block parser, no UID or link validation, no dimension conversion, and no Workbench integration. `source.independent_dual_evidence` is fixture-only evidence metadata, not a Local Model field. Old `positiveIntegerOrSourceMultiplicity` variants need future real-reader tests.
