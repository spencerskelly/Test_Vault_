# Disposable A-14 BOM/variantOf vault

This is a **fixture-only** Obsidian vault. See `90_Test_Instructions/RUNBOOK.md`. No Workbench plugin or governing schema is installed here. The .txt scenario snippets are deliberately not indexed as Markdown. Runtime tests have not been executed.
