---
type: Requirement
uid: 20261008195000003skellyspencer
---
# Non-object

Test-only non-Object endpoint; verify type supported by current test schema.
