---
type: Object
uid: 20261008195000005skellyspencer
---
# Test Assembly

## Local Model
<!-- MDSE:LOCAL-MODEL START schema=0.6 -->
### Parts
#### Cable Length
- definition: [[Family]]
- multiplicity: 2
- quantity: 0.3500000001
- unitOfMeasure: m
^part-20261008195000005skellyspencer
<!-- MDSE:LOCAL-MODEL END -->
