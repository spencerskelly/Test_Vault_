# BOM A-14 disposable Obsidian acceptance vault

**Not a production model, approved MDSE schema, or verified running Obsidian session.**

The `00_Test_Objects` folder starts with a valid-looking Object family link and a Local Model 0.6 read-only fixture. `91_Scenarios_Not_Active` contains **.txt snippets** so they will not be indexed as accidental model notes. Apply one snippet at a time **inside YAML frontmatter** of `Product A.md` (except the cycle snippet, which belongs in `Family.md`). Do not append snippets below the closing `---`.

### Prerequisites
1. Open this folder as a **new disposable Obsidian vault**; do not merge with an Ampure vault.
2. Install a separately built Workbench from `proposal/bom-a14-readonly-quantity-uom`, target `eeda0618d3a566d552f6801eb2e74ea4650b3a47` or a documented newer commit. The compiled plugin is **not included** in this ZIP. Do not install a production release to test proposal-only functionality.
3. Configure **approved-for-test-only copies** of the complete Workbench `element-types.yaml` and `relationships.yaml` files. Include this candidate relation only in the *test* schema: `oneWay` entry `{field: variantOf, from: [Object], to: [Object]}`. This ZIP intentionally does not substitute a partial YAML file for governed complete schemas. Update model schema paths to match Workbench setup, then record revisions.
4. Check `Requirement` is a supported class in the current test schema; if not, use an existing non-Object class consistently.

### Execution
Use `BOM_A14_Obsidian_Runtime_Acceptance.md` in the outer deliverables for R1–R12. Before every case restore Product A to `variantOf: "[[Family]]"`, and Family to **no** `variantOf`, unless the case explicitly specifies otherwise. Record Review findings and timestamps. R10 requires renaming `Family.md`, updating Product A's target, and subsequently reversing the rename. R12 inspects `Test Assembly.md`; **do not save it through a 0.6 writer**.

### Recording results
Use `RESULTS_TEMPLATE.csv` below. Mark unexecuted tests `NOT_RUN`, not PASS. Capture screenshot paths and Obsidian/plugin/schema versions. Stop immediately if the proposal build offers to alter production notes or schemas.
